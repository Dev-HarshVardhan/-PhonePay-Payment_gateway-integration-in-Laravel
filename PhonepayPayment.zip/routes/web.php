<?php

use App\Http\Controllers\PhonepayController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('save', [PhonepayController::class, 'index'])->name('save');




// Route::get('payment', [\App\Http\Controllers\PhonepayController::class, 'index'])->name('payment');


Route::post('pay-now', [\App\Http\Controllers\PhonepayController::class, 'submitPaymentForm'])->name('pay-now');

Route::post('confirm', [\App\Http\Controllers\PhonepayController::class, 'confirmPayment'])->name('confirm');
