Phone Pay PamentGateway Integration in Laravel Step By Step

Step 1: Create a controller
        php artisan make:controller PaymentController
            <?php
                namespace App\Http\Controllers;

                use Illuminate\Http\Request;
                use Illuminate\Support\Facades\Redirect;

                class PhonepayController extends Controller
                {
                public function index()
                {
                    return view('payment-form');
                }
                public function submitPaymentForm(Request $request) {
                        $request->validate([                            
                            'amount'=>'required'                            
                        ],[                            
                            'amount'=>'Amount is Required'                            
                        ]);

                        $amount = $request->input('amount');
                        if($amount !=''){                            
                $merchantId = 'PGTESTPAYUAT86';
                $apiKey = '96434309-7796-489d-8924-ab56988a6076';
                $redirectUrl = route('confirm');
                $order_id = uniqid();                 
                $transaction_data = array(
                    'merchantId' => "$merchantId",
                    'merchantTransactionId' => "$order_id",
                    "merchantUserId"=>$order_id,
                    'amount' => $amount*100,
                    'redirectUrl'=>"$redirectUrl",
                    'redirectMode'=>"POST",
                    'callbackUrl'=>"$redirectUrl",
                "paymentInstrument"=> array(    
                    "type"=> "PAY_PAGE",
                )
                );
                                $encode = json_encode($transaction_data);
                                $payloadMain = base64_encode($encode);
                                $salt_index = 1; //key index 1
                                $payload = $payloadMain . "/pg/v1/pay" . $apiKey;
                                $sha256 = hash("sha256", $payload);
                                $final_x_header = $sha256 . '###' . $salt_index;
                                $request = json_encode(array('request'=>$payloadMain));
                                
                                $curl = curl_init();

                curl_setopt_array($curl, [
                CURLOPT_URL => "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $request,
                CURLOPT_HTTPHEADER => [
                    "Content-Type: application/json",
                    "X-VERIFY: " . $final_x_header,
                    "accept: application/json"
                ],
                ]);
                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                echo "cURL Error #:" . $err;
                } else {
                $res = json_decode($response);
                // Store information into database
                $data = [
                    'amount' => $amount,
                    'transaction_id' => $order_id,
                    'payment_status' => 'PAYMENT_PENDING',
                    'response_msg'=>$response,
                    'providerReferenceId'=>'',
                    'merchantOrderId'=>'',
                    'checksum'=>''
                ];

                // Payment::create($data);
                // end database insert                
                if(isset($res->code) && ($res->code=='PAYMENT_INITIATED')){                
                $payUrl=$res->data->instrumentResponse->redirectInfo->url;                
                return redirect()->away($payUrl);
                }else{
                //HANDLE YOUR ERROR MESSAGE HERE
                            dd('ERROR : ' . $res);
                }
                }
                 }                        
                    }                    
                public function confirmPayment(Request $request) {                        
                if($request->code == 'PAYMENT_SUCCESS')
                {
                $transactionId = $request->transactionId;
                $merchantId=$request->merchantId;
                $providerReferenceId=$request->providerReferenceId;
                $merchantOrderId=$request->merchantOrderId;
                $checksum=$request->checksum;
                $status=$request->code;                
                //Transaction completed, You can add transaction details into database
                $data = [
                'providerReferenceId' => $providerReferenceId,
                'checksum' => $checksum,
                ];
                if($merchantOrderId !=''){
                $data['merchantOrderId']=$merchantOrderId;
                }
                // Payment::where('transaction_id', $transactionId)->update($data); 
                //  dd("OK");
                //   return view('confirm_payment',compact('providerReferenceId', 'transactionId'));
                return view('thanku');

                }else{

                //HANDLE YOUR ERROR MESSAGE HERE
                dd('ERROR : ' .$request->code. ', Please Try Again Later.');
                }
                }
            }

Step 2 :- Create Routes in web.php

    //PAYMENT FORM
    Route::get('payment', [\App\Http\Controllers\PaymentController::class, 'index'])->name('payment');

    //SUBMIT PAYMENT FORM ROUTE
    Route::post('pay-now', [\App\Http\Controllers\PaymentController::class, 'submitPaymentForm'])->name('pay-now');

    //CALLBACK ROUTE
    Route::get('confirm', [\App\Http\Controllers\PaymentController::class, 'confirmPayment'])->name('confirm');


Step 3 :- Let’s Build Your Payment Form
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>PhonePe Payment Gateway Integration in Laravel</title>

        <!-- BOOTSTRAP -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

        <!-- Styles -->
        <style>
        body {
                background: #f7f7f7;
            }

            .form-box {
                max-width: 500px;
                margin: auto;
                padding: 50px;
                background: #ffffff;
                border: 10px solid #f2f2f2;
                margin-top: 100px;
            }
            h1, p {
                text-align: center;
            }

            input, textarea {
                width: 100%;
            }
            .form-control{
                margin-bottom:20px;
            }
        </style>
    </head>
    <body>
    <div class="form-box">
        <h4>Pay with PhonePe</h4>
        <form action="{{ route('pay-with-phonepe') }}" method="post" style="margin-top: 50px;">
            @csrf
            <div class="formgroup">
            <label>Amount</label>
            <input type="number" name="amount" placeholder="Amount" class="form-control">
        </div>
            <button type="submit" class="btn btn-primary">Pay Now</button>
        </form>
    </div>
    </body>
    </html>

Step 4 :- app/Http/Middleware/VerifyCsrfToken.php
    
        <?php
        namespace App\Http\Middleware;
        use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;
        class VerifyCsrfToken extends Middleware
        {
            protected $except = [
                'confirm'
            ];
        }

Step 5:- 
